%% Section 1: Clear all variables
try
    uno.close; %close any existing arudino connections
catch 
        %if closing arduino fails, do nothing
end
clear all; clc; %clear all matlab variables and clear the workspace display


%% Section 2: Set Up Virtual Environment (MuJoCo)
% You should have MuJoCo open with a model loaded and running before
% starting this code!  If your code is crashing during this section, try
% the following: Close MuJoCo, Open MuJoCo, Open Model, Play MuJoCo, Run
% MATLAB Code.
[model_info, movements,command, selectedDigits_Set1, selectedDigits_Set2, VREconnected] = connect_hand;


%% Section 3: Connect to Arduino
[uno, ArduinoConnected]=connect_ard1ch();% can put the comport number in as an argument to bypass automatic connection, useful if more than one arduino uno is connected

%% Section 4: Plot (and control) in real time

% SET UP PLOT
[fig, animatedLines, Tmax, Tmin] = plotSetup1ch();

% INITIALIZATION
[data,control, dataindex, controlindex, prevSamp,previousTimeStamp]=init1ch();
tdata=[0];
tcontrol=[];
pause(0.5)
tic
while(ishandle(fig)) %run until figure closes
    % SAMPLE ARDUINO
    try
        emg = uno.getRecentEMG; % gets the recent EMG values from the Arduino. Values returned will be between -2.5 and 2.5 . The size of this variable will be a 1 x up to 330
        if ~isempty(emg)
            [~,newsamps] = size(emg); % determine how many samples were received since the last call
            data(:,dataindex:dataindex+newsamps-1) = emg(1,:); % add new EMG data to the data vector
            dataindex = dataindex + newsamps; %update sample count
            controlindex = controlindex + 1;
        else
            disp('empty array') %if data from arduino is empty, display "empty array"
        end
    catch
        disp('error')
    end
    if ~isempty(emg)
        % UPDATE
        timeStamp = toc; %get timestamp
        % CALCULATE CONTROL VALUES
        try

            %% %%%%%%%%%%%%%%%%%%%%%%% START OF YOUR CODE %%%%%%%%%%%%%%%%%%%%%%%%%%
            % define noise and signal - assume noise is first part of
            % recording
            noise_section= 1:200;
            signal_section= 200:800;
            % calculate signal power (varience) & noise power (varience)
            signal_power = var(data(1, signal_section));
            noise_power = var(data(1, noise_section));

            % Calculate the SNR 
            snr = 10 * log10(signal_power / noise_power);

       

            threshold = 0.5;
            if dataindex > 800
            samp = data(dataindex - 799:dataindex-1);
            ave = mean(abs(samp));
                if ave > threshold
                   myControlValue = 1;
                else
                   myControlValue = 0;
                end
            else 
                myControlValue = 0;
            end


            %if data(dataindex - 1) > threshold
                    %myControlValue = 1;
            %else
                    %myControlValue = 0;
            %end
 
            


            %% %%%%%%%%%%%%%%%%%%%%%%%% END OF YOUR CODE %%%%%%%%%%%%%%%%%%%%%%%%%%%

            control(1,controlindex) = myControlValue; %update the control parameter with your control value
        catch
            disp('Something broke in your code!')
        end
        tcontrol(controlindex)=timeStamp; %update timestamp
        tempStart = tdata(end);
        tdata(prevSamp:dataindex-1)=linspace(tempStart,timeStamp,newsamps);

        % UPDATE PLOT
        [Tmax, Tmin] = updatePlot1ch(animatedLines, timeStamp, data, control, prevSamp, dataindex, controlindex, Tmax, Tmin);

        % UPDATE HAND
        if(VREconnected) %if connected
            status = updateHand(control, controlindex, command, selectedDigits_Set1, selectedDigits_Set2);
        end
        previousTimeStamp = timeStamp;
        prevSamp = dataindex;
    end
end
%% Section 5: Plot the data and control values from the most recent time running the system
data = data(~isnan(data)); %data is initialized and space is allocated as NaNs. Remove those if necessary.
control = control(~isnan(control)); %data is initialized and space is allocated as NaNs. Remove those if necessary.
finalPlot(data,control,tdata,tcontrol) %plot data and control with their respective timestamps

%% Section 6: Close the arduino serial connection before closing MATLAB
uno.close;