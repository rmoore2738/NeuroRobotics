function site = mj_get_site()
%mj_get_site()
%   return Cartesian positions and orientations of all sites

site = mjhx('get_site');

end
