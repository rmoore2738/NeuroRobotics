function mj_set_applied(applied)
%mj_get_applied()
%   set applied forces in joint and Cartesian space; see output of mj_get_applied

mjhx('set_applied', applied);

end
