function mocap = mj_get_mocap()
%mj_get_mocap()
%   return mocap body positions and orientations

mocap = mjhx('get_mocap');

end
