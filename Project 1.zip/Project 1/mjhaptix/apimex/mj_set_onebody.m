function mj_set_onebody(onebody)
%mj_set_onebody(onebody)
%   set detailed information for one body; see output of mj_get_onebody

mjhx('set_onebody', onebody);

end
