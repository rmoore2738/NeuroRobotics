function tendon = mj_get_tendon()
%mj_get_tendon()
%   return tendon lengths and velocities

tendon = mjhx('get_tendon');

end
