function onebody = mj_get_onebody(bodyid)
%onebody = mj_get_onebody(bodyid)
%   return detailed information for one body

onebody = mjhx('get_onebody', bodyid);

end
