function hx_connect(host, port)
%hx_connect(host, port)
%   connect to specified host (empty: local host)
%   the port is ignored (it is hardwired)

mjhx('hx_connect', host);

end
