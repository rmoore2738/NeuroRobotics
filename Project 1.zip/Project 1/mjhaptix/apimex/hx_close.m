function hx_close
%hx_close
%   close connection to simulator

mjhx('hx_close');

end
