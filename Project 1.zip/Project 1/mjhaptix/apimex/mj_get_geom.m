function geom = mj_get_geom()
%mj_get_geom()
%   return Cartesian positions and orientations of all geoms

geom = mjhx('get_geom');

end
