function dynamics = mj_get_dynamics()
%dynamics = mj_get_dynamics()
%   return dynamics (time-derivatives)

dynamics = mjhx('get_dynamics');

end
