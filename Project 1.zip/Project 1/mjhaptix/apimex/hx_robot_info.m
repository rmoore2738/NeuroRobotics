function info = hx_robot_info
%hx_robot_info
%   return info about the robot: sizes and limits

info = mjhx('hx_robot_info');

end
