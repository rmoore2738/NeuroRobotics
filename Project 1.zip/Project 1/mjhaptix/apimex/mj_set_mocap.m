function mj_set_mocap(mocap)
%mj_set_mocap(mocap)
%   set simulator mocap data; see output of mj_get_mocap

mjhx('set_mocap', mocap);

end
