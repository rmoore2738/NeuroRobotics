function sensor = mj_get_sensor()
%mj_get_mocap()
%   return sensor data

sensor = mjhx('get_sensor');

end
