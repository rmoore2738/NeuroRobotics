function body = mj_get_body()
%mj_get_body()
%   return Cartesian positions and orientations of all bodies

body = mjhx('get_body');

end
