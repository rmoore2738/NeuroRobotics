function force = mj_get_force()
%mj_get_force()
%   return all generalized forces acting on the system

force = mjhx('get_force');

end
