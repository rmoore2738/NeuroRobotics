function sensor = hx_read_sensors
%hx_read_sensors
%   return the sensor data, after a 1000/update_rate ms delay

sensor = mjhx('hx_read_sensors');

end
