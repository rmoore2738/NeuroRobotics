function info = mj_info()
%mj_info()
%   return information about model

info = mjhx('info');

end
