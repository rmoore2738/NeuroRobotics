function mj_step()
%mj_step()
%   advance simulation in paused mode

mjhx('step');

end
