function mj_set_state(state)
%mj_set_state(state)
%   set simulator state; see output of mj_get_state

mjhx('set_state', state);

end
