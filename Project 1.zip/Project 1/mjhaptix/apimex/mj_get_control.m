function control = mj_get_control()
%mj_get_control()
%   return control signals

control = mjhx('get_control');

end
