function applied = mj_get_applied()
%mj_get_applied()
%   return applied forces in joint and Cartesian space

applied = mjhx('get_applied');

end
