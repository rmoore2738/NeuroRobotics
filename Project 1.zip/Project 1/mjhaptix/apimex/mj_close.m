function mj_close
%mx_close
%   close connection to simulator

mjhx('close');

end
