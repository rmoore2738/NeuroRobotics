function state = mj_get_state()
%mj_get_state()
%   return system state

state = mjhx('get_state');

end
