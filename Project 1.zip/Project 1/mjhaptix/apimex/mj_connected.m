function connected = mj_connected
%mj_connected
%   return 1 if connection is live, 0 otherwise

connected = mjhx('connected');

end
