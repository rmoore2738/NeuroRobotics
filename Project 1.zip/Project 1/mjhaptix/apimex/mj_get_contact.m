function contact = mj_get_contact()
%mj_get_contact()
%   return information about all active contacts

contact = mjhx('get_contact');

end
